#include <iostream>
using namespace std;

int main ()
{
    int units;
    int out;
    int tax;

    cout << "Enter the number of units consumed : ";
    cin >> units;

    if (units<=50)
    {out = units*20;}

    if (units>50 && units<=150)
    {units = units-50;
     out = (50*20)+(units*25);}

    if (units>150 && units<=250)
    {units = units-150;
     out = (50*20)+(100*25)+(units*30);}

    if (units>250)
     {units = units-250;
      out = (50*20)+(100*25)+(100*30)+(units*35);}

    tax = out*20/100;
    out = out+tax;

    cout << "Your bill is : " << out << " Rs";

    return 0;
}


