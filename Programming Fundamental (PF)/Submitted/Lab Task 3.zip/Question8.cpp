#include <iostream>
#include<math.h>
using namespace std;

int main ()
{
    int num;
    int a;
    int b;
    int c;
    int d;
    int e;

    cout << "Enter a 5-Digit number : ";
    cin >> num;

    a = num/10000+1;
    b = num%10000;
    b = b/1000+1;
    c = num%1000;
    c = c/100+1;
    d = num%100;
    d = d/10+1;
    e = num%10+1;

    cout << "After adding 1 to each digit, the new number is : " << a << b << c << d << e;

    return 0;
}


