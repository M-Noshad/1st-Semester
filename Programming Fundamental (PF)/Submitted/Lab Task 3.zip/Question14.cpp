#include<iostream>
#include <iomanip>
using namespace std;

int main ()
{
    float airtime;
    float text;
    float extra_airtime;
    float extra_text;
    float base_charge;
    float _1122_charge;
    float total_bill;
    float tax;

    base_charge = 10;
    _1122_charge = 0.5;
    tax = 5;

    cout << "Enter the number of airtime minutes : ";
    cin >> airtime;
    cout << "Enter the number of text messages : ";
    cin >> text;
    cout << "Base charge for 40 airtime minutes and 60 text messages : " << base_charge << " $" << endl;

    if (airtime>40)
    {airtime = airtime-40;
     extra_airtime = airtime*0.20;
     cout << "Additional airtime charges : " << extra_airtime << " $" << endl;}

    if (text>60)
    {text = text-60;
     extra_text = text*0.10;
     cout << "Additional text charges : " << extra_text << " $" << endl;}

     cout << "1122 charge : " << _1122_charge << " $" << endl;
     cout << "Tax charge : " << tax << " %" << endl;

     total_bill = base_charge+_1122_charge+extra_airtime+extra_text;
     tax = total_bill*tax/100;
     total_bill = total_bill+tax;

     cout << setprecision(4);
     cout << "Total bill : " << total_bill << " $";


     return 0;
}
