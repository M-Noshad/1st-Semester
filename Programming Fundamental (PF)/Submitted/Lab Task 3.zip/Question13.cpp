#include <iostream>
using namespace std;

int main ()
{
    int no_of_chocolates;
    float weight_of_chocolates;
    float weight;
    char choice;

    cout << "Enter the number of chocolates sold : ";
    cin >> no_of_chocolates;

    cout << "Enter the weight of single chocolate in ounce : ";
    cin >> weight_of_chocolates;

    cout << "Enter 'O' for weight in ounce" << endl;
    cout << "Enter 'P' for weight in pound" << endl;
    cout << "Enter 'G' for weight in gram" << endl;
    cout << "Enter 'K' for weight in kilogram" << endl;
    cin >> choice;

    if (choice=='O')
    {weight = no_of_chocolates*weight_of_chocolates;
     cout << "The weight of chocolates in ounce is : " << weight;}

    else if (choice=='P')
    {weight = (no_of_chocolates*weight_of_chocolates)/16;
     cout << "The weight of chocolates in pound is : " << weight;}

    else if (choice=='G')
    {weight = (no_of_chocolates*weight_of_chocolates)*28.3495;
     cout << "The weight of chocolates in gram is : " << weight;}

    else if (choice=='K')
    {weight = (no_of_chocolates*weight_of_chocolates)*0.0283495;
     cout << "The weight of chocolates in kilogram is : " << weight;}

    return 0;
}


