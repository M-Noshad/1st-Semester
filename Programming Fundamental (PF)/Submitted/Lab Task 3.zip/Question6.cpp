#include <iostream>
#include<math.h>
using namespace std;

int main ()
{
    int input;
    int no_1;
    int no_5;
    int no_10;
    int no_50;
    int no_100;

    cout << "Enter the amount of currency in hundreds : ";
    cin >> input;

    no_100 = input/100;
    input = input%100;
    no_50 = input/50;
    input = input%50;
    no_10 = input/10;
    input = input%10;
    no_5 = input/5;
    no_1 = input%5;

    cout << "No. of hundred notes : " << no_100 << endl;
    cout << "No.of fifty notes : " << no_50 << endl;
    cout << "No. of ten notes : " << no_10 << endl;
    cout << "No. of five notes : " << no_5 << endl;
    cout << "No. of one notes : " << no_1;

    return 0;
}


