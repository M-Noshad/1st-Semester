#include <iostream>
using namespace std;

int main ()
{
    float F;
    float C;

    cout << "Enter the temperature in fahrenheit : ";
    cin >> F;

    C = (F-32)*5/9;

    cout << "The temperature in celsius is : " << C << " C";

    return 0;
}


