#include <iostream>
using namespace std;

int main ()
{
    float l;
    float w;
    float a;

    cout << "Enter the length of rectangle : ";
    cin >> l;

    cout << "Enter the width of rectangle : ";
    cin >> w;

    a = l*w;
    cout << "The area of rectangle is : " << a;

    return 0;
}


