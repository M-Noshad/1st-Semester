#include <iostream>
using namespace std;

int main ()
{
    float d1;
    float d2;
    float km;
    float m;
    float ft;
    float inch;
    float cm;

    cout << "Enter the distance of first city : ";
    cin >> d1;

    cout << "Enter the distance of second city : ";
    cin >> d2;
    cout << endl;
    if (d1>d2)
    {km = d1-d2;}
    else
    {km = d2-d1;}

    m = km*1000;
    ft = m*3.28;
    inch = ft*12;
    cm = inch*2.54;

    cout << "Distance between cities in kilometers : " <<km << endl;
    cout << "Distance between cities in meters : " <<m << endl;
    cout << "Distance between cities in feet : " <<ft << endl;
    cout << "Distance between cities in inch : " <<inch << endl;
    cout << "Distance between cities in centimeters : " <<cm;

    return 0;
}


