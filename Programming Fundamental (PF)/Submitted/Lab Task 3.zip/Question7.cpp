#include <iostream>
#include<math.h>
using namespace std;

int main ()
{
    int num;
    int a;
    int b;
    int c;
    int sum;
    int result;

    cout << "Enter a 3-Digit number : ";
    cin >> num;

    a = num/100;
    b = num%100;
    b = b/10;
    c = num%10;

    sum = a+b+c;

    result = c*100 + b*10 + a;

    cout << "Sum of the entered digits is : " << sum << endl;
    cout << "Reverse of entered number is : " << result;

    return 0;
}


