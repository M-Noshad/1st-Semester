#include <iostream>
#include<math.h>
using namespace std;

int main ()
{
    float a;
    float b;
    float c;
    float q;
    float r;
    float m;
    float z;

    cout << "Enter the value of a : "; cin >> a;
    cout << "Enter the value of b : "; cin >> b;
    cout << "Enter the value of c : "; cin >> c;
    cout << "Enter the value of q : "; cin >> q;
    cout << "Enter the value of r : "; cin >> r;
    cout << "Enter the value of m : "; cin >> m;

    z = (8.8*(a+b)*2/c-0.5+2*a/(q+r))/((a+b)*(1/m));

    cout << "Answer is : " << z;

    return 0;
}


