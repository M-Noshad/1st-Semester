#include <iostream>
#include<math.h>
using namespace std;

int main ()
{
    int day;
    int year;
    int month;
    int week;

    cout << "Enter the number of days : ";
    cin >> day;

    year = day/365;
    day = day%365;
    month = day/30;
    day = day%30;
    week = day/7;
    day = day%7;

    cout << "No. of years : " << year << endl;
    cout << "No. of months : " << month << endl;
    cout << "No. of weeks : " << week << endl;
    cout << "No. of days : " << day << endl;

    return 0;
}


