#include <iostream>
#include<math.h>
using namespace std;

int main ()
{
    float L;
    float B;
    float R;
    float A_rect;
    float P_rect;
    float A_circle;
    float C_circle;

    cout << "Enter the length of rectangle : ";
    cin >> L;

    cout << "Enter the breadth of rectangle : ";
    cin >> B;

    cout << "Enter the radius of circle : ";
    cin >> R;

    A_rect = L*B;
    P_rect = 2*(L+B);

    A_circle = 3.14*pow(R,2);
    C_circle = 2*3.14*R;

    cout << "The area of rectangle is : " << A_rect << endl;
    cout << "The perimeter of rectangle is : " << P_rect << endl << endl;

    cout << "The area of circle is : " << A_circle << endl;
    cout << "The circumference of circle is : " << C_circle;



    return 0;
}


