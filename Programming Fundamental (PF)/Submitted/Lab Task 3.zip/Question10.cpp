#include <iostream>
using namespace std;

int main ()
{
    int num;

    cout << "Enter a number : ";
    cin >> num;

    if (num >= 0)
    {cout << "It is a Positive number" << endl;}
    else
    {cout << "It is a Negative number" << endl;}

    if (num%2==0)
    {cout << "It is an Even number";}
    else
    {cout << "It is an Odd number";}

    return 0;
}


